import os
import pandas as pd

# ==========================================================
# CONFIGURACIÓN
# ==========================================================

ARCHIVO_EXCEL = "empleados.xlsx"

ESTADO_INICIO = "INICIO"
ESTADO_ESPERANDO_LEGAJO = "ESPERANDO_LEGAJO"
ESTADO_VALIDANDO_LEGAJO = "VALIDANDO_LEGAJO"
ESTADO_CONSULTANDO_SALDO = "CONSULTANDO_SALDO"
ESTADO_ESPERANDO_DIAS = "ESPERANDO_DIAS"
ESTADO_VALIDANDO_DIAS = "VALIDANDO_DIAS"
ESTADO_CONFIRMACION = "CONFIRMACION"
ESTADO_ACTUALIZANDO = "ACTUALIZANDO"
ESTADO_FINALIZADO = "FINALIZADO"


# ==========================================================
# FUNCIONES DE UTILIDAD
# ==========================================================

def limpiar_pantalla():
    os.system("cls" if os.name == "nt" else "clear")


def pausar():
    input("\nPresione ENTER para continuar...")


# ==========================================================
# CARGA DE DATOS
# ==========================================================

def cargar_empleados():

    ruta = os.path.join(os.path.dirname(__file__), ARCHIVO_EXCEL)

    try:

        empleados = pd.read_excel(ruta)

    except FileNotFoundError:

        print("\nERROR")
        print("No se encontró el archivo empleados.xlsx")
        print("Debe estar en la misma carpeta que vacaciones.py")
        exit()

    except PermissionError:

        print("\nERROR")
        print("El archivo empleados.xlsx está abierto.")
        print("Ciérrelo e intente nuevamente.")
        exit()

    columnas = [
        "Legajo",
        "Nombre",
        "Dias_Disponibles"
    ]

    for columna in columnas:

        if columna not in empleados.columns:

            print(f"\nFalta la columna: {columna}")
            exit()

    return empleados


def guardar_empleados(empleados):

    ruta = os.path.join(os.path.dirname(__file__), ARCHIVO_EXCEL)

    try:

        empleados.to_excel(
            ruta,
            index=False
        )

    except PermissionError:

        print("\nERROR")
        print("No fue posible guardar el archivo.")
        print("Verifique que Excel esté cerrado.")
        return False

    return True


# ==========================================================
# BÚSQUEDAS
# ==========================================================

def buscar_empleado(empleados, legajo):

    resultado = empleados[
        empleados["Legajo"] == legajo
    ]

    if resultado.empty:
        return None

    return resultado.iloc[0]


# ==========================================================
# VALIDACIONES
# ==========================================================

def validar_legajo(texto):

    texto = texto.strip()

    if texto == "":
        return False, "El legajo no puede estar vacío."

    if not texto.isdigit():
        return False, "El legajo debe contener únicamente números."

    legajo = int(texto)

    if legajo <= 0:
        return False, "El legajo debe ser mayor que cero."

    return True, legajo


def validar_dias(texto):

    texto = texto.strip()

    if texto == "":
        return False, "Debe ingresar una cantidad."

    if not texto.isdigit():
        return False, "Solo se permiten números."

    dias = int(texto)

    if dias <= 0:
        return False, "Debe solicitar al menos un día."

    return True, dias


# ==========================================================
# IMPRESIÓN
# ==========================================================

def encabezado():

    limpiar_pantalla()

    print("=" * 55)
    print("CHATBOT DE GESTIÓN DE VACACIONES")
    print("TecnoMarket S.A.")
    print("=" * 55)

# ==========================================================
# CHATBOT
# ==========================================================

def chatbot():

    empleados = cargar_empleados()

    continuar = True

    while continuar:

        estado = ESTADO_INICIO

        empleado = None
        legajo = None
        saldo = 0
        dias = 0

        while estado != ESTADO_FINALIZADO:

            # --------------------------------------------------

            if estado == ESTADO_INICIO:

                encabezado()

                print("Bienvenido al sistema de solicitud de vacaciones.\n")

                estado = ESTADO_ESPERANDO_LEGAJO

            # --------------------------------------------------

            elif estado == ESTADO_ESPERANDO_LEGAJO:

                entrada = input("Ingrese su número de legajo: ")

                valido, resultado = validar_legajo(entrada)

                if not valido:

                    print(f"\nERROR: {resultado}")
                    pausar()
                    continue

                legajo = resultado

                estado = ESTADO_VALIDANDO_LEGAJO

            # --------------------------------------------------

            elif estado == ESTADO_VALIDANDO_LEGAJO:

                empleado = buscar_empleado(
                    empleados,
                    legajo
                )

                if empleado is None:

                    print("\nNo existe un empleado con ese legajo.")
                    pausar()

                    estado = ESTADO_ESPERANDO_LEGAJO

                else:

                    estado = ESTADO_CONSULTANDO_SALDO

            # --------------------------------------------------

            elif estado == ESTADO_CONSULTANDO_SALDO:

                nombre = empleado["Nombre"]
                saldo = int(empleado["Dias_Disponibles"])

                encabezado()

                print(f"Empleado : {nombre}")
                print(f"Legajo   : {legajo}")
                print(f"Saldo    : {saldo} días\n")

                if saldo <= 0:

                    print("No posee días disponibles.")
                    estado = ESTADO_FINALIZADO

                else:

                    estado = ESTADO_ESPERANDO_DIAS

            # --------------------------------------------------

            elif estado == ESTADO_ESPERANDO_DIAS:

                entrada = input(
                    "¿Cuántos días desea solicitar?: "
                )

                valido, resultado = validar_dias(entrada)

                if not valido:

                    print(f"\nERROR: {resultado}")
                    pausar()
                    continue

                dias = resultado

                estado = ESTADO_VALIDANDO_DIAS

            # --------------------------------------------------

            elif estado == ESTADO_VALIDANDO_DIAS:

                if dias > saldo:

                    print(
                        f"\nLa cantidad solicitada ({dias}) "
                        f"supera el saldo disponible ({saldo})."
                    )

                    print("\nIntente nuevamente.")

                    pausar()

                    estado = ESTADO_ESPERANDO_DIAS

                else:

                    estado = ESTADO_CONFIRMACION

            # --------------------------------------------------

            elif estado == ESTADO_CONFIRMACION:

                print("\nResumen de la solicitud")
                print("---------------------------")
                print(f"Empleado : {nombre}")
                print(f"Días     : {dias}")
                print("---------------------------")

                opcion = input(
                    "\n¿Desea confirmar la solicitud? (S/N): "
                ).upper().strip()

                if opcion == "S":

                    estado = ESTADO_ACTUALIZANDO

                elif opcion == "N":

                    print("\nSolicitud cancelada por el usuario.")

                    estado = ESTADO_FINALIZADO

                else:

                    print("\nDebe responder únicamente S o N.")

                    pausar()

            # --------------------------------------------------

            elif estado == ESTADO_ACTUALIZANDO:

                nuevo_saldo = saldo - dias

                empleados.loc[
                    empleados["Legajo"] == legajo,
                    "Dias_Disponibles"
                ] = nuevo_saldo

                if guardar_empleados(empleados):

                    print("\nSolicitud aprobada correctamente.")

                    print(f"Saldo anterior : {saldo}")

                    print(f"Días solicitados : {dias}")

                    print(f"Nuevo saldo : {nuevo_saldo}")

                else:

                    print(
                        "\nLa solicitud no pudo guardarse."
                    )

                estado = ESTADO_FINALIZADO

        print("\nProceso finalizado.")

        respuesta = input(
            "\n¿Desea realizar otra solicitud? (S/N): "
        ).upper().strip()

        if respuesta != "S":

            continuar = False

# ==========================================================
# MAIN
# ==========================================================

def main():

    try:

        chatbot()

    except KeyboardInterrupt:

        print("\n\nEl programa fue cancelado por el usuario.")

    except Exception as error:

        print("\nSe produjo un error inesperado.")
        print(f"Detalle técnico: {error}")

    finally:

        print("\nGracias por utilizar el Chatbot de Gestión de Vacaciones.")
        print("TecnoMarket S.A.")
        print("=" * 55)


# ==========================================================
# PUNTO DE ENTRADA
# ==========================================================

if __name__ == "__main__":
    main()